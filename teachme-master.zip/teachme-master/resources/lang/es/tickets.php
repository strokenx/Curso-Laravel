<?php

return array(

    'latest_title' => 'Solicitudes recientes',
    'open_title' => 'Solicitudes abiertas',
    'closed_title' => 'Tutoriales',
    'popular_title' => 'Solicitudes populares',

    'total' => '{0} No hay :title'
        . '|{1} Sólo hay una :title'
        . '|[2,Inf] Hay :count :title',

    'status' => array(
        'open' => 'Abierta',
        'closed' => 'Finalizada'
    )

);