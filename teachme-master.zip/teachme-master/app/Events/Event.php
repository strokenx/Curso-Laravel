<?php

namespace TeachMe\Events;

abstract class Event
{
    //
}
