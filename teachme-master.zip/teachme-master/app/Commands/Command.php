<?php

namespace TeachMe\Commands;

abstract class Command
{
    //
}
