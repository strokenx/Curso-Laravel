<?php

return array(

    'menu' => array(
        'tickets.latest'  => 'Recientes',
        'tickets.popular' => 'Populares',
        'tickets.open'    => 'Abiertas',
        'tickets.closed'  => 'Finalizadas'
    )

);